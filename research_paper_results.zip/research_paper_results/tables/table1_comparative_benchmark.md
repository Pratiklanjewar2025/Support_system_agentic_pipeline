| Configuration | Hit@1 (%) | Hit@3 (%) | Fault Macro-F1 | Structured Correct (%) | Brier Score | ECE | Cost / 1k ($) | Median Latency $p50$ (s) | Tail Latency $p95$ (s) |
|:---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| Baseline A (Command-R 35B) | 42.4% | 66.7% | 0.368 | 45.0% | 0.162 | 0.224 | $0.040 | 2.1s | 3.8s |
| Baseline B (Nemotron 3.5) | 42.4% | 66.7% | 0.368 | 45.0% | 0.162 | 0.224 | $0.000 | 4.3s | 7.5s |
| Baseline C (Command-R+ 104B) | 52.3% | 78.5% | 0.442 | 52.5% | 0.141 | 0.198 | $0.678 | 11.2s | 18.6s |
| Baseline D (Query-Only Router) | 42.4% | 66.7% | 0.368 | 45.0% | 0.158 | 0.215 | $0.026 | 2.0s | 3.6s |
| Proposed E (AdaRAG Pareto) | 46.8% | 72.4% | 0.41 | 49.0% | 0.112 | 0.148 | $0.036 | 2.4s | 4.1s |
| Proposed F (Learned RF) | 48.2% | 74.1% | 0.425 | 50.5% | 0.098 | 0.125 | $0.027 | 2.3s | 3.9s |
| Proposed G (Verification Esc.) | 54.6% | 83.3% | 0.485 | 58.0% | 0.0808 | 0.12 | $0.257 | 3.8s | 7.1s |
| **Proposed H (Calibrated Interv.)** | 57.1% | 85.7% | 0.512 | 61.5% | 0.0406 | 0.0812 | $0.231 | 3.4s | 6.2s |
| **Proposed H + Persistent Cache** | 57.1% | 85.7% | 0.512 | 61.5% | 0.0406 | 0.0812 | $0.023 | 0.19s | 0.29s |