| Cache Configuration | Hit Rate (%) | Precision (%) | Cost Reduction (%) | LLM Call Reduction (%) | Lookup Latency $p50$ |
|:---|:---:|:---:|:---:|:---:|:---:|
| **Config A (No Cache Baseline)** | 0.0% | 100.0% | 0.0% | 0.0% | 0.011 ms |
| **Config B (Exact Hash Only)** | 30.0% | 100.0% | 25.03% | 27.05% | 6.532 ms |
| **Config C (Exact + Semantic $\tau=0.95$)** | **40.0%** | **100.0%** | **33.71%** | **36.07%** | **26.901 ms** |
