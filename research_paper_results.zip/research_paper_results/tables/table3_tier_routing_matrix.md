| Tier ID | Representative Model | Provider | Cost / 1k Tokens | Latency ($p50$) | Dynamic Routing Activation Trigger |
|:---|:---|:---|:---:|:---:|:---|
| **Tier 0: Zero-Cost** | NVIDIA Nemotron 3 Ultra (550B Free) | **OpenRouter** | **$0.00000** | 2.60s | Routine procedural runbooks, high retrieval confidence ($r_{\text{conf}} \ge 0.40$, complexity $\le 0.48$). |
| **Tier 1: Fast Triage** | OpenAI GPT-OSS 20B | **Groq** | $0.00010 | **1.20s** | Urgent triage alerts, monitoring pings, latency-critical SLA responses ($<2\text{s}$). |
| **Tier 2: High Reasoning**| Gemini 2.5 Flash | **Gemini** | $0.00015 | 3.80s | Multi-hop causal reasoning, latency spikes, low-retrieval certainty ($r_{\text{conf}} < 0.40$). |
| **Tier 3: Heavy Outage** | Command-R+ (104B) | **Cohere** | $0.00250 | 8.50s | Critical cascading outages, contradictory telemetry, multi-service deadlocks ($c > 0.65$). |
