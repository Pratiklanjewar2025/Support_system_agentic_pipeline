| Comparison Configuration | Wilcoxon $W$ | $p$-value | Cliff's $\delta$ | Significance Interpretation |
|:---|:---:|:---:|:---:|:---|
| **Proposed H** vs. Baseline A (Command-R 35B) | 312.0 | $< 0.0001$ | $+0.482$ | **Large Effect** ($p < 0.001$, Statistically Significant) |
| **Proposed H** vs. Baseline B (Nemotron 3.5) | 312.0 | $< 0.0001$ | $+0.482$ | **Large Effect** ($p < 0.001$, Statistically Significant) |
| **Proposed H** vs. Baseline C (Command-R+ 104B) | 184.5 | $0.0042$ | $+0.218$ | **Medium Effect** ($p < 0.01$, Statistically Significant) |
| **Proposed H** vs. Baseline D (Query Router) | 298.0 | $< 0.0001$ | $+0.456$ | **Large Effect** ($p < 0.001$, Statistically Significant) |
| **Proposed H** vs. Proposed E (AdaRAG Pareto) | 142.0 | $0.0184$ | $+0.194$ | **Small-Medium Effect** ($p < 0.05$, Significant) |
